package BUS;

import DAO.HoaDonDAO;
import DAO.ChiTietHoaDonDAO;
import DTO.HoaDonDTO;
import DTO.ChiTietHoaDonDTO;
import java.util.ArrayList;

public class HoaDonBUS {
    private final HoaDonDAO hoaDonDAO;
    private final ChiTietHoaDonDAO chiTietHoaDonDAO;

    public HoaDonBUS() {
        hoaDonDAO = new HoaDonDAO();
        chiTietHoaDonDAO = new ChiTietHoaDonDAO();
    }

    public ArrayList<HoaDonDTO> getAllHoaDon() {
        return (ArrayList<HoaDonDTO>) hoaDonDAO.getAllWithNames();
    }

    public ArrayList<HoaDonDTO> searchHoaDon(String keyword) {
        return hoaDonDAO.searchWithNames(keyword);
    }
    public boolean deleteHoaDon(int id) {
        return hoaDonDAO.deleteInvoice(id);
    }

    public ArrayList<ChiTietHoaDonDTO> getChiTietByMaHD(int maHD) {
        return chiTietHoaDonDAO.getDetailsByInvoiceId(maHD);
    }
}

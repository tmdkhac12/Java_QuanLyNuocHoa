package DAO;

import DTO.NuocHoaDTO;
import java.util.ArrayList;
import util.DBConnection;
import java.sql.*;

public class NuocHoaDAO {
    public ArrayList<NuocHoaDTO> getAllNuocHoa() {
        ArrayList<NuocHoaDTO> nuochoa = new ArrayList<>();
        Connection connection = DBConnection.getConnection();
        try {
            String query = "SELECT p.id, p.name, p.sex, p.brand_id, b.name AS brand_name, " +
                           "p.scent_type_id, s.type_name AS scent_name, p.stock " +
                           "FROM perfume p " +
                           "JOIN brand b ON p.id = b.id " +
                           "JOIN scenttype s ON p.id = s.id";
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String sex = rs.getString("sex");
                int brandId = rs.getInt("brand_id");
                String brandName = rs.getString("brand_name");
                int scentTypeId = rs.getInt("scent_type_id");
                String scentName = rs.getString("scent_name");
                int stock = rs.getInt("stock");

                NuocHoaDTO nh = new NuocHoaDTO(id, name, sex, brandId, brandName, scentTypeId, scentName, stock);
                nuochoa.add(nh);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return nuochoa;
    }
}

package DAO;

import DTO.ChiTietHoaDonDTO;
import util.DBConnection;

import java.sql.*;
import java.util.ArrayList;

public class ChiTietHoaDonDAO {

    /** Lấy danh sách chi tiết theo invoice_id */
    public ArrayList<ChiTietHoaDonDTO> getDetailsByInvoiceId(int invoiceId) {
        ArrayList<ChiTietHoaDonDTO> list = new ArrayList<>();
        String sql =
            "SELECT d.invoice_id, d.perfume_id, " +
            "       p.name        AS perfume_name, " +
            "       p.gender, p.type, p.brand, p.price, " +
            "       d.quantity " +
            "FROM invoicedetail d " +
            "JOIN perfume p ON d.perfume_id = p.id " +
            "WHERE d.invoice_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, invoiceId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new ChiTietHoaDonDTO(
                    rs.getInt("invoice_id"),
                    rs.getInt("perfume_id"),
                    rs.getString("perfume_name"),
                    rs.getString("gender"),
                    rs.getString("type"),
                    rs.getString("brand"),
                    rs.getDouble("price"),
                    rs.getInt("quantity")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
